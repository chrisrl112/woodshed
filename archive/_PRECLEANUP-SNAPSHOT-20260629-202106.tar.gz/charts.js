/* THE WOODSHED — user-imported charts (created by the score-to-woodshed skill).
   Each entry: {id, title, source, key, style, bpm, abc, bars}
   bars = CONCERT-pitch chord array (the band plays these); abc = notation as printed. */
window.USER_CHARTS=(window.USER_CHARTS||[]).concat([{
  id: 'blue-bossa-head-8',
  title: 'Blue Bossa — head, bars 1–8',
  source: 'Real Book B♭ 6th ed., p.50 — pixel-verified by two independent transcription passes',
  key: 'Dm (written for B♭; concert Cm)',
  style: 'bossa',
  bpm: 140,
  abc: `X:1
T:Blue Bossa — head, bars 1–8 (written for B♭)
C:Kenny Dorham
L:1/8
M:4/4
K:Dm
A2 |:"D-" a3 g fe z d-| d4- dc z B-|"G-7" B4- Ba z g-|"C7" g6 z2 |
"E-7b5" g3 f ed z c-|"A7#5(#9)" c4- cB z A-|"D-" A4- Ag z f-| f6 z2 |]`,
  // CONCERT-pitch chords for the band: written (B♭ part) minus a whole step.
  bars: [['Cm7'], ['Cm7'], ['Fm7'], ['Bb7'], ['Dm7b5'], ['G7alt'], ['Cm7'], ['Cm7']]
}]);
